HYPERTRIX - HANDOFF FOR YNGVAR - 14 OCTOBER 2026

Start with Hypertrix_Hybrid_Research_Update_2026-10-14.pdf.
The two landscape architecture sheets are embedded in the report and also
available separately as Hypertrix_Architecture_2026-10-14.pdf.
Editable prose is in docs/hybrid_research_update.md. Other docs retain context
and distinguish the historical runs from current architecture.
docs/architecture_notes.md expands the protocol map and proposed security tests.
Descriptive evidence references in the PDF link to its evidence guide.

The evidence is public metadata, certificates, signed claims and test results.
It contains no node private keys, cloud credentials, private archives, raw book
bodies, embedding table or trained model binaries. The GPU node is a diagnostic
observer, not an admitted consensus auditor. No model was trained.

Offline package validation (Python 3 with cryptography installed):
  python verify_handoff.py Hypertrix_Yngvar_Handoff_2026-10-14.zip

This checks all manifest hashes, the GPU report's Ed25519 signature, report/input
bindings, result counts and historical signed DHT advertisements. It does NOT
verify the CometBFT quorum signatures, current freshness or truth of claims.
The pilot's independent Go verifier checked certificates during execution.
MANIFEST.json provides integrity, not an external timestamp or independent trust.

Live reproduction requires the full DAWL repository and pinned public inputs.
The focused implementation files here are an inspection snapshot, not a turnkey
cluster distribution. Do not clone a live validator. Read docs/gpu_run_001.md
before using the WSL-specific scripts. Historic discovery records have expired;
their observation timestamps, rather than the present time, define the test.

PDF builders: implementation/scripts/build_hybrid_report.py and
implementation/scripts/build_architecture_sheets.py, run within the full
repository with reportlab, matplotlib and pypdf. Review rendered output after edits.
The GPU source files exactly match hashes inside the signed report.

Infrastructure lifecycle records remain in the historical evidence and operator
runbooks. This report focuses on architecture and experimental results.
