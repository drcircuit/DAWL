DAWL technical research handoff for Yngvar
Prepared 13 October 2026

Start with DAWL_technical_research_brief.pdf (13 pages).
The docs directory contains existing architecture/runbooks and public execution evidence.
The research protocol and R001 summary/raw trials are copied from the separate research branch.
SHA256SUMS.json identifies the exact bytes in this bundle; it is a transport integrity
manifest, not an externally authenticated trust anchor. Signed claims still require
the intended independently obtained policy pins and correct verifier software.

This is a documentation and evidence bundle, not a self-contained platform deployment.
It excludes private keys, full source/model artifacts, Python environments and live state.
The repository and pinned large artifacts are needed to reproduce platform execution.
Some original logs contain machine-local paths; these are retained as historical evidence.

Editable document source: scripts/build_research_brief.py. It contains the prose, tables,
equations and plotting code. To rebuild after extracting this ZIP, install the listed
document dependencies and run: python scripts/build_research_brief.py
The regenerated PDF appears in output/pdf; intermediate figures appear in tmp/pdfs.
Review all rendered pages after edits. The script checks pagination and formula arithmetic.
Document build dependencies: reportlab, matplotlib, numpy, pypdf and Pillow.
See build-environment.json for the exact installed versions used.

These files preserve completed results. No new training or human study was performed
while preparing the handoff. Future experiments are labelled as proposals in the brief.
