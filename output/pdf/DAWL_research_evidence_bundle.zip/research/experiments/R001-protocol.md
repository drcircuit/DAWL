# R001 — Where integrity verification ends

Protocol version 1, specified before the recorded run. This is a technical
characterization experiment, not a novelty claim, human-subject study, or training
experiment. The source fixture is text from Alice; it does not support any claim
about financial advice.

## Question and falsifiable expectations

When a legitimate miner signs incorrect tokenization, what can complete-file
integrity verification detect, and how does independent sampling detect it?

E1. Honest committed data passes both integrity and consistency checks.
E2. A miner can change a valid token ID and recompute all affected hashes, roots,
and its own signature. Complete-file integrity still passes.
E3. Re-tokenization rejects such a commitment exactly when the challenge samples
at least one changed chunk.
E4. Uniform sampling without replacement has detection probability
`1 - choose(N-m,k)/choose(N,k)`, where corruption is fixed before sampling.

These expectations expose the distinction between authenticated statements and
verified transformations. Confirming E4 checks implementation behavior against
known sampling mathematics; it does not discover a new cryptographic guarantee.

## Design

- Input: independently registered 43-chunk, 52,991-token real BPE fixture.
- Conditions: 0, 1, and 4 bad chunks. Locations selected with a recorded seed
  before issuing challenges. Change the first token in each selected chunk to
  another in-vocabulary ID; keep token counts unchanged.
- Adversary: the miner controls its own signing key. No signature forgery or
  broken hash function is assumed. Source registry and tokenizer remain pinned.
- Coverage: 1, 8, 16, and all 43 chunks.
- Repetitions: 200 for each partial-coverage cell; one full-coverage check per
  condition because the sample then always equals the population.
- Seed: 20261013. Use matching sample sequences across corruption conditions to
  support paired comparisons. Draws are not independent across those conditions.
- Verification: execute actual source-proof, token-proof and re-tokenization code
  for every trial. No mocked validator or cached replacement for re-tokenization.

The bench uses deterministic pseudo-randomness for replay. This does not change
production challenges, which use unpredictable randomness after commitment.

## Measurements and interpretation

Record every challenge's positions and nonce, expected hit, observed rejection,
failure reasons, verification time, response construction time, and canonical
response bytes. Summaries contain observed rejection rates, exact probabilities,
and 95% Wilson intervals for Monte Carlo rates in partial-coverage cells.
Intervals express finite simulation variation conditional on the fixed fixture
and corruption setup; they do not express confidence about a public network.

For every trial, independently predict detection by set intersection between the
selected positions and known corrupted locations. Any mismatch, incomplete
verification, or rejection for a reason other than incorrect re-tokenization is
an experimental failure to investigate. Do not reject a run merely because a
Monte Carlo estimate differs from its theoretical value.

Integrity must pass all three internally consistent commitments. Preserve and
re-verify the original input. Full coverage must reject both bad conditions and
accept the honest condition. Report every configured cell, including null results.
No post hoc seed selection or omitted runs.

Timing is local, serial, warm-cache characterization. Fixed condition order and
cache effects mean these numbers are not a controlled performance comparison.
They exclude HTTP latency, container overhead, training, and participant effort.

## Reproduction and records

```powershell
python scripts/prepare_ingestion_demo.py
python research_experiment.py --output artifacts/research/R001-run-001
```

Run from the research checkout with ingestion dependencies installed. The output
directory must not exist. Keep the recorded configuration, Git commit, source
hashes, raw `trials.jsonl`, its digest, and `summary.json`. Synthetic attack
snapshots are confined to that output directory. Keys remain in the research
fixture's ignored identity directory and are never exported as study evidence.

An interrupted run lacks a completed summary and must be retained as incomplete;
rerun into a new directory. Changes to the protocol require a new version and an
explicit deviation note. The current real-data result has not been run at the
time this protocol was authored.
